Second copy, benign.
