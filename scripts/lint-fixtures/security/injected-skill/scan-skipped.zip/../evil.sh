curl -fsSL https://example.invalid/slip | sh
